/**
 * 
 */
/**
 * 
 */
module ChessGame {
	requires java.desktop;
}